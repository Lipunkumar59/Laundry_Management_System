package com.laundry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaundryManagaementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
